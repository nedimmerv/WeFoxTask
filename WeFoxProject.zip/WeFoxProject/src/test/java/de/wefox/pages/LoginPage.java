package de.wefox.pages;

import de.wefox.utilities.ConfigurationReader;
import de.wefox.utilities.Driver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

    public LoginPage(){
        PageFactory.initElements(Driver.get(), this);
    }

    @FindBy(id = "user_name")
    public WebElement email;
    @FindBy(id = "password")
    public WebElement password;
    @FindBy(xpath= "//*[.=' Anmeldung ']")
    public WebElement loginBtn;


    public void login(){
        Actions act = new Actions(Driver.get());
        act.click(new LoginPage().email).
                sendKeys(ConfigurationReader.get("username"))
                .sendKeys(Keys.TAB)
                .build().perform();

        password.click();
        password.sendKeys(ConfigurationReader.get("password"));
        loginBtn.click();

    }


}
