package de.wefox.pages;

import de.wefox.utilities.Driver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;


public class MainPage{

    public MainPage(){ PageFactory.initElements(Driver.get(),this); }
    @FindBy(xpath = "//img[@alt='NAME IN APP DE AT']")
    public WebElement image;
    @FindBy(xpath = "//a[@title='My Contracts']")
    public WebElement myContracts;
    @FindBy(xpath = "//*[.='No contracts added']")
    public WebElement label;
    @FindBy(xpath ="//a[@title='Profile']")
    public WebElement profile;
    @FindBy(xpath = "//*[.='Personal details']")
    public WebElement personalInfo;
    @FindBy(xpath = "//a[@icon='logout']")
    public WebElement logout;
    @FindBy(xpath = "//label[@class='wf-c-field__label']")
    public List<WebElement> labels;



    public List<String> labelInfo(){
        List<String>labelText= new ArrayList<>();
        labels.forEach(label->labelText.add(label.getText()));
        return labelText;
    }
}
