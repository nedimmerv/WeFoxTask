package de.wefox.tests;

import de.wefox.pages.LoginPage;
import de.wefox.pages.MainPage;
import org.testng.annotations.Test;


import static org.testng.Assert.assertTrue;

public class ImageLoadedTest extends TestBase {
    /*
Enter next credentials, do login and then check that the agent image is loaded:
. { User: aqawefox+testtecnico@wefoxgroup.com
, Pass: qwertyasdf }
     */
    @Test
            public void imageIsEnabled(){
    LoginPage loginPage=new LoginPage();
    loginPage.login();
        MainPage mainPage=new MainPage();
        mainPage.image.click();
        assertTrue(mainPage.image.isDisplayed());
        assertTrue(mainPage.image.isEnabled());
}
}