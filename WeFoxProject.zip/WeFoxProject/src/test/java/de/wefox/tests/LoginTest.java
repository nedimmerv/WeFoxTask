package de.wefox.tests;


import de.wefox.pages.LoginPage;
import de.wefox.utilities.Driver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import static org.testng.Assert.*;


public class LoginTest extends TestBase {


    @Test(priority = 1)
    public void WebPage(){
        /*
        Go to “https://my.wefox.de/login” (use Chrome browser).
         */
        report.setSystemInfo("User should be able to see login page", "passed");
        String actualUrl=driver.getCurrentUrl();
        String expectedUrl="https://my.wefox.de/login";
        assertEquals(actualUrl,expectedUrl);
    }
    @Test(priority = 2)
    public void pageLoadTitle(){
        /*
        Check that the page loaded is the expected one.
         */
        String actualTitle= driver.getTitle();
        String expectedTitle= "wefox";
        assertEquals(actualTitle,expectedTitle);
    }
    @Test(priority = 3)
    public void login(){
        /*
        Enter next credentials, do login and then check that the agent image is loaded:
. { User: aqawefox+testtecnico@wefoxgroup.com
, Pass: qwertyasdf }
         */
        new LoginPage().login();
        String expectedTitle = "Dashboard - wefox";
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String actualTitle = Driver.get().getTitle();
        assertEquals(actualTitle, expectedTitle);
    }




}
