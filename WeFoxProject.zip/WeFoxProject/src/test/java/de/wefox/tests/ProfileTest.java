package de.wefox.tests;

import com.google.gson.Gson;
import de.wefox.pages.LoginPage;
import de.wefox.pages.MainPage;
import org.testng.annotations.Test;

import java.util.*;

import static org.testng.Assert.*;

public class ProfileTest extends TestBase {
/*
Click on profile section then click on personal Data button, check that personal information is
displayed (check if a name field is displayed or whatever), after that save it in a json file all user
information and print on console.

 */
    @Test
    public void goToProfilePage(){
        new LoginPage().login();
        MainPage mainPage = new MainPage();
        mainPage.profile.click();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String expectedUrl = "https://my.wefox.de/account";
        String actualUrl = driver.getCurrentUrl();
        assertEquals(expectedUrl,actualUrl);
        mainPage.personalInfo.click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        expectedUrl = "https://my.wefox.de/account/personal-details";
        actualUrl = driver.getCurrentUrl();
        assertEquals(expectedUrl,actualUrl);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Map<String,String> profileInfo = new LinkedHashMap<>();

        List<String> columnInfo = new ArrayList<>();
        columnInfo.add("test");
        columnInfo.add("testtest1testtest1test");
        columnInfo.add("Alexanderplatz 70");
        columnInfo.add("10178");
        columnInfo.add("Berlin");
        columnInfo.add("21.02.1999");
        columnInfo.add("aqawefox+testtecnico@wefoxgroup.com");
        columnInfo.add("+34 615835882");

        System.out.println("mainPage.labelInfo() = " + mainPage.labelInfo());

        for (int i = 0; i <mainPage.labelInfo().size() ; i++) {
            profileInfo.put(mainPage.labelInfo().get(i),columnInfo.get(i));
        }
        System.out.println("profileinfo " + profileInfo.toString());
        Gson gson = new Gson();
        String jsonBody = gson.toJson(profileInfo);
        //Json body is written in console
        System.out.println(jsonBody);


    }


}
