package de.wefox.tests;

import de.wefox.pages.LoginPage;
import de.wefox.pages.MainPage;
import de.wefox.utilities.Driver;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class ContractsTest  extends TestBase {
/*
Click on contracts sections and check the label “No contracts added”.

 */
    @Test
    public void contracts(){
    LoginPage loginPage = new LoginPage();
    loginPage.login();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        MainPage mainPage = new MainPage();
        mainPage.myContracts.click();

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String expectedUrl = "https://my.wefox.de/contracts";
        String actualUrl = Driver.get().getCurrentUrl();
        assertEquals(actualUrl,expectedUrl);
        String expectedLabel = "No contracts added";
        String actualLabel = mainPage.label.getText();
        assertEquals(actualLabel, expectedLabel);
    }






}
