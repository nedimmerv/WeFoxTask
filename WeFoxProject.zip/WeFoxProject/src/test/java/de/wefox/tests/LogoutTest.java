package de.wefox.tests;

import de.wefox.pages.LoginPage;
import de.wefox.pages.MainPage;
import de.wefox.utilities.Driver;
import org.testng.annotations.Test;


import static org.testng.Assert.assertEquals;

public class LogoutTest extends TestBase{
/*
 Click on logout then check that the wefox web was loaded.
 */
    @Test
    public void logout(){
        new LoginPage().login();
        MainPage mainPage = new MainPage();
        mainPage.logout.click();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String expectedUrl = "https://my.wefox.de/login";
        String actualUrl = Driver.get().getCurrentUrl();
        assertEquals(actualUrl,expectedUrl);

    }
}
