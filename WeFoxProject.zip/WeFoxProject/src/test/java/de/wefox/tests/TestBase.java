package de.wefox.tests;

import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import de.wefox.utilities.ConfigurationReader;
import de.wefox.utilities.Driver;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import com.aventstack.extentreports.*;
import java.util.concurrent.TimeUnit;

public class TestBase {
    protected WebDriver driver;

    public ExtentReports report;
    public ExtentHtmlReporter htmlReporter;
    public ExtentTest extentTest;


    @BeforeTest
    public void setUp(){
        report = new ExtentReports();
        String projectPath = System.getProperty("user.dir");
        String path = projectPath +"/test-output/report.html";

        htmlReporter = new ExtentHtmlReporter(path);
        report.attachReporter(htmlReporter);
        report.setSystemInfo("Tester", "Nedim Yilmaz");

        driver = Driver.get();
        driver.manage().window().maximize();
        driver.get(ConfigurationReader.get("loginUrl"));
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @AfterTest
    public void tearDown(){
        report.flush();
        driver.quit();
    }


}
